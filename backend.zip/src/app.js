// Main backend application
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');

// Import database and models
const db = require('./config/db');
const Facility = require('./models/facility');
const User = require('./models/user');
const ChatMessage = require('./models/chatMessage');

// Import and initialize email service
const { initializeEmailService } = require('./services/emailService');

// Import routes
const facilityRoutes = require('./routes/facilities');
const otpRoutes = require('./routes/otpRoutes');
const adminRoutes = require('./routes/adminRoutes');
const usersRoutes = require('./routes/users');
const notificationsRoutes = require('./routes/notificationsRoutes');
const chatRoutes = require('./routes/chatRoutes');
const hospitalTypesRoutes = require('./routes/hospitalTypes');
const pharmacyTypesRoutes = require('./routes/pharmacyTypes');
const uploadsRoutes = require('./routes/uploads');

// Initialize Express app
const app = express();
const PORT = process.env.PORT || 5000;

// ============================================
// IMPORTANT: Set database in app for routes to access
// ============================================
app.set('db', db);

// Security middleware
app.use(helmet());
app.use(cors({
  origin: [
    process.env.FRONTEND_ORIGIN || 'https://admin-lpya.onrender.com',
    'https://admin-lpya.onrender.com',
    'http://localhost:3000',
    'http://192.168.55.60:3000'
  ],
  credentials: true
}));

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 300, // limit each IP to 300 requests per windowMs (increased for development)
  message: 'Too many requests from this IP, please try again later.',
  standardHeaders: true,
  legacyHeaders: false,
});
app.use(limiter);

// Body parsing middleware
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Logging middleware
app.use(morgan('combined'));

// Health check endpoint
app.get('/health', (req, res) => {
  res.status(200).json({ 
    status: 'OK', 
    timestamp: new Date().toISOString(),
    uptime: process.uptime()
  });
});

// CSRF token endpoint
app.get('/api/csrf-token', (req, res) => {
  const crypto = require('crypto');
  const token = crypto.randomBytes(32).toString('hex');
  res.json({ csrfToken: token });
});

// API routes
app.use('/api/facilities', facilityRoutes);
app.use('/api/otp', otpRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/users', usersRoutes);
app.use('/api/notifications', notificationsRoutes);
app.use('/api/chat', chatRoutes);
app.use('/api/hospital-types', hospitalTypesRoutes);
app.use('/api/pharmacy-types', pharmacyTypesRoutes);
app.use('/api/uploads', uploadsRoutes);
app.use('/api/content', (req, res) => {
  res.json({ message: 'Content endpoint working', data: { content: 'Static content for the app' } });
});

// Add places endpoint
app.use('/api/places', (req, res) => {
  res.json({ message: 'Places endpoint working', data: { places: 'Places data for the app' } });
});

// Add markers endpoint  
app.use('/api/markers', (req, res) => {
  res.json({ message: 'Markers endpoint working', data: { markers: 'Markers data for the app' } });
});

// OTP request logging middleware
app.use('/api/otp', (req, res, next) => {
  const timestamp = new Date().toISOString();
  console.log(`\n🔐 [${timestamp}] OTP API Request:`);
  console.log(`📋 Method: ${req.method}`);
  console.log(`🛣️  Path: ${req.originalUrl}`);
  console.log(`📧 Body: ${JSON.stringify(req.body)}`);
  console.log(`🌐 IP: ${req.ip || req.connection.remoteAddress}`);
  console.log(`📱 User-Agent: ${req.get('User-Agent') || 'Unknown'}`);
  console.log('─'.repeat(50));
  
  // Store the original send function
  const originalSend = res.send;
  res.send = function(data) {
    const timestamp = new Date().toISOString();
    console.log(`✅ [${timestamp}] OTP API Response:`);
    console.log(`📊 Status: ${res.statusCode}`);
    console.log(`📦 Response: ${data}`);
    console.log('═'.repeat(50));
    originalSend.call(this, data);
  };
  
  next();
});

// Root endpoint
app.get('/', (req, res) => {
  res.json({ 
    message: 'Facility Management Backend API',
    version: '1.0.0',
    endpoints: {
      facilities: '/api/facilities',
      otp: '/api/otp',
      hospitalTypes: '/api/hospital-types',
      pharmacyTypes: '/api/pharmacy-types',
      health: '/health'
    }
  });
});

// 404 handler
app.use('*', (req, res) => {
  res.status(404).json({ 
    message: 'Route not found',
    path: req.originalUrl
  });
});

// Global error handler
app.use((err, req, res, next) => {
  console.error('Global error handler:', err);
  
  if (err.name === 'ValidationError') {
    return res.status(400).json({
      message: 'Validation Error',
      details: err.message
    });
  }
  
  if (err.code === 'LIMIT_FILE_SIZE') {
    return res.status(413).json({
      message: 'File too large'
    });
  }
  
  res.status(500).json({
    message: 'Internal Server Error',
    error: process.env.NODE_ENV === 'development' ? err.message : 'Something went wrong'
  });
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully');
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('SIGINT received, shutting down gracefully');
  process.exit(0);
});

// ============================================
// FIXED: Initialize database with proper error handling
// ============================================
async function initializeDatabase() {
  try {
    console.log('📦 Initializing database...');
    
    if (typeof db.testConnection === 'function') {
      await db.testConnection();
      console.log('✅ Database connection test passed');
    } else {
      console.log('⚠️ Database testConnection method not available, skipping test');
    }
    
    if (typeof db.syncDatabase === 'function') {
      await db.syncDatabase();
      console.log('✅ Database synced');
    }
    
    if (Facility && typeof Facility.createTable === 'function') {
      try {
        await Facility.createTable();
        console.log('✅ Facilities table ready');
      } catch (err) {
        if (!err.message.includes('already exists')) {
          console.error('❌ Error creating facilities table:', err.message);
        }
      }
    }
    
    if (User && typeof User.createTable === 'function') {
      try {
        await User.createTable();
        console.log('✅ Users table ready');
      } catch (err) {
        if (!err.message.includes('already exists')) {
          console.error('❌ Error creating users table:', err.message);
        }
      }
    }
    
    if (ChatMessage && typeof ChatMessage.createTable === 'function') {
      try {
        await ChatMessage.createTable();
        console.log('✅ ChatMessages table ready');
      } catch (err) {
        if (!err.message.includes('already exists')) {
          console.error('❌ Error creating chatMessages table:', err.message);
        }
      }
    }
    
    console.log('✅ Database initialization complete');
  } catch (error) {
    console.error('❌ Database initialization error:', error.message);
    console.log('⚠️ Continuing without database...');
  }
}

initializeEmailService().then(() => {
  console.log('📧 Email service initialized');
}).catch((error) => {
  console.log('⚠️ Email service failed to initialize, using fallback:', error.message);
});

initializeDatabase().catch((error) => {
  console.error('❌ Initial database setup failed:', error.message);
});

module.exports = app;